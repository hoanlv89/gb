## UniWebView - An easier solution for integrating WebView to your mobile games

Thank you for purchasing UniWebView!

To get started with this asset, we strongly suggest to open demo scenes to play 
with the main features of UniWebView. You could use `0.Top` scene as a start point. 
Once you get familiar with UniWebView and ready to publish your game, you could 
feel free to remove the demo folder under UniWebView, to prevent the demo scripts 
compiled to your game.

For more information (including manual and script refernce), please visit our 
officail website of UniWebView: http://uniwebview.onevcat.com

If you encountered any problem when using UniWebView, please refer to our help 
desk to get support: https://onevcat.zendesk.com

Best regards.

From UniWebView Team.
